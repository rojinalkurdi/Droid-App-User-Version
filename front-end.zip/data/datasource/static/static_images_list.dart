List categoriesImages = [
 'assets/images/laptop.jpg',
 'assets/images/camera.jpg',
 'assets/images/dress.jpg',
 'assets/images/shoes.jpg',
 'assets/images/mobile.jpg',

];
