// ignore_for_file: file_names

enum StatusRequest {
  none,
  loading,
  success,
  failure,
  serverFailure,
  offlineFailure
}