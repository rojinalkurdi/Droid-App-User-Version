import 'package:flutter/animation.dart';

import 'package:flutter/material.dart';

class AppColors {
  //static const Color purple = Color.fromARGB(255, 123, 43, 215);
  static const Color grey = Color(0xffBCBCBC);
  static const Color purple = Color.fromARGB(255, 159, 25, 159);
  //static const Color babyPurple = Color(0xffAB47BC);
  static const Color babyPurple = Color(0xffBA68C8);

  static const Color babyBlue = Color(0xff89CFF0);
  static const Color babyBlueLight = Color(0xff40C4FF);
  static const Color blue = Color.fromARGB(255, 9, 137, 197);
  static const Color pink = Color(0xffDD2697);
  static const Color babyPink = Color(0xffF4C2C2);
  //static const Color darkYellow = Color(0xffFFA000);
  
  //static const Color secColor = Color(0xffFFECB3);
 
 //kammun

  static const Color darkYellow = Color(0xff00838F);
  static const Color secColor = Color.fromARGB(255, 153, 239, 250);



  //terkoaz
  //static const Color darkYellow = Color(0xff00695C);
  //static const Color secColor = Color(0xff26A69A);
  

}
