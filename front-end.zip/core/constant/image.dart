// ignore_for_file: camel_case_types

class onBoardingImages {
  static const logoAuth = 'assets/images/nlogo.jpg';
  static const choosepic = 'assets/images/choose.png';
  static const paypic = 'assets/images/payment.png';
  static const trackpic = 'assets/images/track.png';
  static const carpic = 'assets/images/car.png';
  static const sale = 'assets/images/sale.svg';
  static const motor = 'assets/images/motor.svg';
  static const truck = 'assets/images/truck.svg';
  static const loading = 'assets/lottie/98288-loading.json';
  static const nodata = 'assets/lottie/13659-no-data.json';
  static const servererror = 'assets/lottie/119787-webpage-error.json';
  static const offline = 'assets/lottie/101931-lost-connection.json';
  static const faliure = 'assets/lottie/90569-error.json';
  
  
}
